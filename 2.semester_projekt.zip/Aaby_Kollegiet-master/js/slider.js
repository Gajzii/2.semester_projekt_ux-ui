var slideIndex4 = 1;
showSlides4(slideIndex4);

function plusSlides4(n) {
    showSlides4((slideIndex4 += n));
}

function currentSlide4(n) {
    showSlides4((slideIndex4 = n));
}

function showSlides4(n) {
    var i;
    //var slides = document.querySelectorAll(".mySlides4");
    var slides = document.getElementsByClassName("mySlides4");
    var dots = document.getElementsByClassName("dot4");
    if (n > slides.length) {
        slideIndex4 = 1;
    }
    if (n < 1) {
        slideIndex4 = slides.length;
    }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active4", "");
    }
    slides[slideIndex4 - 1].style.display = "block";
    dots[slideIndex4 - 1].className += " active4";
}
